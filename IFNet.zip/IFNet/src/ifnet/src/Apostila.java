/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifnet.src;

/**
 *
 * @author gabriel
 */
public class Apostila extends Material {
    private String area;

    public Apostila(String area, String titulo, String categoria, Usuario usuario) {
        super(titulo, categoria, usuario);
        
        this.area = area;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
