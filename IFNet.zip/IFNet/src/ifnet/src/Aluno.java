/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifnet.src;

/**
 *
 * @author gabriel
 */
public class Aluno extends Usuario {
    
    public Aluno(String nome, String prontuario, String email) {
        super(nome, prontuario, email);
    }
}
